export const logos = {
    Figma: './assets/tools/Figma.png',
    Adobe: './assets/tools/adobe.png',
    Illustrator: './assets/tools/Illustrator.png',
    Photoshop: './assets/tools/Photoshop.png',
    AfterEffects: './assets/tools/AfterEffects.png',
    Indesign: './assets/tools/Indesign.png',
    PremierePro: './assets/tools/PremierePro.png',
    React: './assets/tools/react.png',
    JS: './assets/tools/js.webp',
    HTML: './assets/tools/html.png',
    CSS: './assets/tools/css.png',
    Node: './assets/tools/Node.png'
  }