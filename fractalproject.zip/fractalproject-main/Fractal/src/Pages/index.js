//Landing

export * from './landingPage/LandingPage'
//Services
export * from './servicePages/UserExperiencePage/UserExperiencePage'

//Projects
export * from './projectsPage/projectsPage'

// Paginas admin
export * from './loginPage/LoginPage'
export * from './submitPage/SubmitPage'

export * from './testPage/testPage'
