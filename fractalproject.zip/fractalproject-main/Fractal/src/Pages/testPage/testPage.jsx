import React from 'react'
import { ModalProject } from '../../components'

export function TestPage () {

    return (
      <>
        <ModalProject />
      </>
    )
  }
  